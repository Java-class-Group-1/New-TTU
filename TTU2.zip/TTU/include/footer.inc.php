  <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer text-center">
          All Rights Reserved by TTU Students. Designed and Developed by
          <a href="https://www.inbitfirm.com">TTU Students</a>.
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
      </div>
      <!-- ============================================================== -->
      <!-- End Page wrapper  -->
      <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../public/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../public/dist/js/jquery.ui.touch-punch-improved.js"></script>
    <script src="../public/dist/js/jquery-ui.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../public/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../public/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../public/assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../public/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../public/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../public/dist/js/custom.min.js"></script>
    <!-- this page js -->
    <script src="../public/assets/libs/moment/min/moment.min.js"></script>
    <script src="../public/assets/libs/fullcalendar/dist/fullcalendar.min.js"></script>
    <script src="../public/dist/js/pages/calendar/cal-init.js"></script>
  
   <!-- All Jquery -->
    
    <script src="../public/assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
    <script src="../public/assets/extra-libs/multicheck/jquery.multicheck.js"></script>
    <script src="../public/assets/extra-libs/DataTables/datatables.min.js"></script>
    <script>
      /****************************************
       *       Basic Table                   *
       ****************************************/
      $("#zero_config").DataTable();
    </script>  
  </body>
</html>
